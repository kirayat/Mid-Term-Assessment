﻿using System;

namespace Mid_tern_Assessment_7
{
    internal class formPermut
    {
        internal void prnPermut(int[] arr1, int v1, int v2)
        {
            throw new NotImplementedException();
        }
    }
}