﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mid_tern_Assessment_7
{
    internal class Program
    {
                   class formPermut
            {
                public void swapTwoNumber(ref int a, ref int b)
                {
                    int temp = a;
                    a = b;
                    b = temp;
                }
                public void prnPermut(int[] list, int k, int m)
                {
                    int i;
                    if (k == m)
                    {
                        for (i = 0; i <= m; i++)
                            Console.WriteLine("{0}", list[i]);
                        Console.WriteLine(" ");
                    }
                    else
                        for (i = k; i <= m; i++)
                        {
                            swapTwoNumber(ref list[k], ref list[i]);
                            prnPermut(list, k + 1, m);
                            swapTwoNumber(ref list[k], ref list[i]);
                        }
                }
            }
            class RecExercise11
            {
                public static void Main()
                {
                    int n, i;
                    formPermut test = new formPermut();
                    int[] arr1 = new int[5];

                    Console.WriteLine(" Generate all possible permutations of an array :");
                    Console.WriteLine(" Input the number of elements to store in the array [maximum 5 digits ] :");
                    n = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine(" Input {0} number of elements in the array :", n);
                    for (i = 0; i < n; i++)
                    {
                        Console.WriteLine(" element - {0} : ", i);
                        arr1[i] = Convert.ToInt32(Console.ReadLine());
                    }

                    Console.WriteLine(" The Permutations with a combination of {0} digits are : ", n);
                    test.prnPermut(arr1, 0, n - 1);
                    Console.WriteLine("");
                }
            }
    }
}

