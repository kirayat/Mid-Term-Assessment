﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mid_term_Assessment_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string username = "user";
            string pw = "pass";

            Console.WriteLine("Input a username: ");
            string usernameInput = Console.ReadLine();

            Console.WriteLine("Input a password: ");
            string passwordInput = Console.ReadLine();

            if ((usernameInput == "user" && passwordInput == "password") || (usernameInput == "abcd" && passwordInput == "1234"))
            {
                Console.WriteLine("Password entered successfully!");
            }
        }
    }
}
