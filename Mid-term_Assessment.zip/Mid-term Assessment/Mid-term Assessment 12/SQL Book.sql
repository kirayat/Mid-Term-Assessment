--CREATE DATABASE MidTermAssessment;

CREATE TABLE BOOK (

BookID int primary key,
BookName varchar(255),
AuthorName varchar(255),
PublishingDate varchar(255),
Price float
);

select * from BOOK

insert into BOOK (BookID, BookName, AuthorName, PublishingDate, Price)
VALUES ('001','Harry Potter','J.K.Rowling','26 Jun 1997','350');
VALUES ('002','Naruto','Masashi Kishimoto','3 Oct 2002','250');
VALUES ('003','Demon Slayer','Koyoharu Gotouge','16 Feb 2016','250');

