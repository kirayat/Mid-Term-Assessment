﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mid_term_Assessment_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Input the number of elements to be stored in the array:");
            int arrSize = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Input " + arrSize + " elements in the array :");

            int[] numbers = new int[3];

            for (int i = 0; i < arrSize; i++)
            {
                Console.WriteLine("element-" + i + " : ");
                numbers[i] = Convert.ToInt32(Console.ReadLine());
            }

            Console.WriteLine("The unique elements found in the array are:");
                foreach (var i in numbers.GroupBy(i => i).Where(g => g.Count() == 1).Select(g => g.Key))

            Console.WriteLine(i);
        }
    }
}
