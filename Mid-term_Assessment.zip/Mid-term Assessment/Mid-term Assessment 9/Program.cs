﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mid_term_Assessment_9
{
    class Program
    {
        static void Main(string[] args)
        {
            /*string chst, chen;
            char ch;
            string[] cities =
            {
                "ROME","LONDON","NAIROBI","CALIFORNIA","ZURICH","NEW DELHI","AMSTERDAM","ABU DHABI", "PARIS"
            };

            Console.WriteLine("LINQ : Find the string which starts and ends with a specific character : ");
            Console.WriteLine("The cities are : 'ROME','LONDON','NAIROBI','CALIFORNIA','ZURICH','NEW DELHI','AMSTERDAM','ABU DHABI','PARIS' ");

            Console.WriteLine("Input starting character for the string : ");
            ch = (char)Console.Read();
            chst = ch.ToString();
            Console.WriteLine("Input ending character for the string : ");
            ch = (char)Console.Read();
            chen = ch.ToString();


            var _result = from x in cities
                          where x.StartsWith(chst)
                          where x.EndsWith(chen)
                          select x;
            Console.WriteLine("");
            foreach (var city in _result)
            {
                Console.WriteLine("The city starting with {0} and ending with {1} is : {2} ", chst, chen, city);
            }

            Console.ReadLine();*/


            string[] cities =
            {
            "ROME","LONDON","NAIROBI","CALIFORNIA","ZURICH","NEW DELHI","AMSTERDAM","ABU DHABI", "PARIS"
            };

            string chstart = "A";
            string chend = "M";

            var result = cities.Where(p => p.StartsWith(chstart) && p.EndsWith(chend));
            foreach (var city in result)
            {
                Console.WriteLine("The city starting with {0} and ending with {1} is : {2} ", chstart, chend, city);
            }
        }
    }
}
