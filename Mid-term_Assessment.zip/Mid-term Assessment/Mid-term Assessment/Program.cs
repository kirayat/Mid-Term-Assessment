﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mid_term_Assessment
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Input the number of elements to be stored in the array:"); int arrSize = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Input " + arrSize + " elements in the array :");

            int[] numbers = new int[3];

            for (int i = 0; i < arrSize; i++)
            {
                Console.WriteLine("element-" + i + " : ");
                numbers[i] = Convert.ToInt32(Console.ReadLine());
            }

            int sum = numbers.Sum();

            Console.WriteLine("Sum of all elements stored in the array is " + sum);
        }
    
    }
}
