﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mid_term_Assessment_8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string str;

            Console.WriteLine("LINQ : Display the characters and frequency of character from giving string : ");
            Console.WriteLine("Input the string : ");
            str = Console.ReadLine();
            Console.WriteLine("");

            var FreQ = from x in str
                       group x by x into y
                       select y;
            Console.WriteLine("The frequency of the characters are :");
            foreach (var ArrEle in FreQ)
            {
                Console.WriteLine("Character " + ArrEle.Key + ": " + ArrEle.Count() + " times");
            }
        }
    }
}
